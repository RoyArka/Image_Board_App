const DELETE = "DELETE";
const GET = "GET";
const POST = "POST";
const PUT = "PUT";
const UPDATE = "UPDATE";

module.exports = {
  DELETE,
  GET,
  POST,
  PUT,
  UPDATE,
};
